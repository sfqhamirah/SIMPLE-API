﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using ApiWebService.Models;

namespace ApiWebService.Controllers
{
    [ApiController]
    [Route("api/[controller]")] // Base route: api/subject
    public class ValuesController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        // Constructor to inject IConfiguration to access connection string
        public ValuesController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        // GET API
        // Example URL: https://localhost:5001/api/subject?NO=A123456
        [HttpGet]
        public IActionResult GetPIC([FromQuery] string NO)
        {
            // Initialize subject to null (will hold DB result if found)
            Employees? subject = null;

            // Get connection string from appsettings.json
            string connStr = _configuration.GetConnectionString("DefaultConnection")!;

            // Using SqlConnection to connect to the database
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                // SQL query to fetch PIC column from EDM_REQUEST table where SRNO = @No
                string query = "SELECT LAST_NAME FROM StaffList WHERE EMPLOYEE_ID = @No";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add parameter to prevent SQL injection
                    cmd.Parameters.AddWithValue("@No", NO);

                    conn.Open(); // Open database connection

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        // If a record is found, read the PIC value
                        if (reader.Read())
                        {
                            subject = new Employees
                            {
                                EMPLOYEE_ID = NO,
                                LAST_NAME = reader["LAST_NAME"]?.ToString()
                            };
                        }
                    }
                }
            }

            // If no matching record found, return 404 Not Found
            if (subject == null)
                return NotFound();

            // Return 200 OK with the subject data as JSON
            return Ok(subject);
        }

        // POST API
        // Example URL: https://localhost:5001/api/subject/save-result
        // Expects JSON body with NRIC and Result fields
        [HttpPost]
        [Route("save-result")]
        public IActionResult SaveResult([FromBody] Result resultData)
        {
            // Get connection string
            string connStr = _configuration.GetConnectionString("DefaultConnection")!;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                // SQL Insert query to add NRIC and Result into AmirahTest table
                string query = "INSERT INTO StaffResult (NRIC, Result) VALUES (@NRIC, @Result)";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add parameters with values from the request body
                    cmd.Parameters.AddWithValue("@NRIC", resultData.NRIC);
                    cmd.Parameters.AddWithValue("@Result", resultData.ResultValue);

                    conn.Open(); // Open connection
                    int rowsAffected = cmd.ExecuteNonQuery(); // Execute insert command

                    // If at least one row inserted successfully
                    if (rowsAffected > 0)
                        return Ok("Data inserted successfully.");
                    else
                        return BadRequest("Insert failed.");
                }
            }
        }
    }
}
