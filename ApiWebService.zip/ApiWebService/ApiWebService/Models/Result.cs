﻿namespace ApiWebService.Models
{
    public class Result
    {
        public string NRIC { get; set; } = string.Empty;
        public string ResultValue { get; set; } = string.Empty;
    }
}
