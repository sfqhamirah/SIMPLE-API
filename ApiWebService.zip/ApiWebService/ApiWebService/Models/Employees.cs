﻿namespace ApiWebService.Models
{
    public class Employees
    {
        public string EMPLOYEE_ID { get; set; } = string.Empty;
        public string? LAST_NAME { get; set; }
    }
}
